﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EOD
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        double[] inflacja = new double[] { 3.5, 2.6,4.3, 3.7, 0.9, 0.0, -0.9, -0.6, 2.0, 1.6, 2.3, 3.4, 5.1, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0 };
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int dlugoscObligacji = 10;
            int wartoscPoczatkowa = 0;
            double wartoscKoncowa = 0;
            double zysk = 0;
            double procentZysku = 0;
            double sredniaRocznaStopaZysku = 0;
            int indeksInflacji = (int)rokSlider.Value;
            int iloscObligacji = 0;
            if(!Int32.TryParse(iloscObligacjiTBox.Text.Replace('.', ','), out iloscObligacji))
            {
                iloscObligacji = 1;
            }
            int lata = 0;
            int miesiace = 0;
            if(wczesniejRbtn.IsChecked == true)
            {
                if (!Int32.TryParse(miesiacTBox.Text.Replace('.', ','), out miesiace ) || miesiace > 12)
                {
                    miesiace = 0;
                }
                if (!Int32.TryParse(lataTBox.Text.Replace('.', ','), out lata) || lata > 9)
                {
                    lata = 0;
                }
                dlugoscObligacji -= lata ;
                
            }
            double oprocentowaniePierwsze ;
            if (!Double.TryParse(oprocentowaniePierwszeTBox.Text.Replace('.', ','), out oprocentowaniePierwsze)) 
            {
                oprocentowaniePierwsze = 7.25;
            }
            double wlasnaInflacja = 0;
            if (!Double.TryParse(wlasnaInflacjaTBox.Text.Replace('.', ','), out wlasnaInflacja))
            {
                wlasnaInflacja = 2;
            }
            double marza ;
            if (!Double.TryParse(marzaTBox.Text.Replace('.', ','), out marza))
            {
                marza = 1.25;
            }
           
            
            
            wartoscKoncowa= wartoscPoczatkowa = iloscObligacji * 100;
            
            for (int i = 0; i < dlugoscObligacji; i++)
            {
                if (i != 0)
                {
                    if(inflacjaWlasnaRbtn.IsChecked == true)
                    {
                        wartoscKoncowa *= (1 + (wlasnaInflacja + marza) / 100);
                    }
                    else if (i == dlugoscObligacji - 1)
                    {
                        if (inflacjaWlasnaRbtn.IsChecked == true)
                        {
                            wartoscKoncowa *= (1 + ((12 - miesiace) / 12) * (wlasnaInflacja + marza) / 100);
                        }
                        else
                        {
                            if (inflacja[indeksInflacji] < 0)
                            {
                                wartoscKoncowa *= (1 + ((12 - miesiace) / 12) * ( marza) / 100);
                            }
                            else
                            {
                                wartoscKoncowa *= (1 + ((12 - miesiace) / 12) * (inflacja[indeksInflacji] + marza) / 100);
                            }
                            if (wczesniejRbtn.IsChecked == true)
                            {
                                abebae.Content = (wartoscKoncowa).ToString();
                                wartoscKoncowa = wartoscKoncowa - 2 * iloscObligacji;
                                if (wartoscKoncowa < wartoscPoczatkowa)
                                {
                                    wartoscKoncowa = wartoscPoczatkowa;
                                }
                            }
                        }
                        
                    }
                    else
                    {
                        if (inflacja[indeksInflacji] < 0)
                        {
                            wartoscKoncowa *= (1 + (marza) / 100);
                        }
                        else
                        {
                            wartoscKoncowa *= (1 + (inflacja[indeksInflacji] + marza) / 100);
                        }
                    }
                    
                    indeksInflacji++;
                }
                else
                {
                    wartoscKoncowa *= (1 + oprocentowaniePierwsze / 100);
                }
                abebae.Content = wartoscKoncowa.ToString();
            }
            abebae.Content = "";
           
            zysk = Math.Round(wartoscKoncowa - wartoscPoczatkowa, 4) ;
            procentZysku = Math.Round((wartoscKoncowa / wartoscPoczatkowa - 1) * 100, 4);
            sredniaRocznaStopaZysku = Math.Round(procentZysku / ((dlugoscObligacji * 12 + miesiace) / 12), 4) ;
            
            wartoscKoncowaTBlock.Text = Math.Round(wartoscKoncowa,2).ToString();
            
            wartoscPoczatkowaTBlock.Text = wartoscPoczatkowa.ToString();
            zyskTBlock.Text = zysk.ToString();
            procentTBlock.Text = procentZysku.ToString();
            rocznaStopaTBlock.Text = sredniaRocznaStopaZysku.ToString();
        }

        private void rokSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            var obj = sender as Slider;
            
            if (obj != null)
            {
                double rok = obj.Value + 2009;
                string tekst = "";
                tekst += rok + " do " + (rok+10);
                DataContext = tekst;
            }
            
        }
    }
}
//< RadioButton x: Name = "inflacjaJedenRbtn"  Content = "2021 - 2011" />
//                        < RadioButton x: Name = "inflacjaDwaRbtn"    Content = "2020 - 2010" />
//                        < RadioButton x: Name = "inflacjaTrzyRbtn"   Content = "2018 - 2008" />
//                        < RadioButton x: Name = "inflacjaCzteryRbtn" Content = "2015 - 2005" />